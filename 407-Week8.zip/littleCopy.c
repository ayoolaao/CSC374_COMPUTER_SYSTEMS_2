#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

#define BUFFER_SIZE 256

int main (int argc, const char* argv[])
{
  const char* fromFileCPtr;
  const char* toFileCPtr;

  if (argc < 3)
  {
    fprintf(stderr,"Usage: littleCopy <fromFile> <toFile>\n");
    return(EXIT_FAILURE);
  }

  fromFileCPtr = argv[1];
  toFileCPtr = argv[2];

  /* YOUR CODE HERE */
  int	fdIn	= open(fromFileCPtr,O_RDONLY,0);

  if  (fdIn == -1)
  {
    fprintf(stderr,"Could not open %s.\n",fromFileCPtr);
    exit(EXIT_FAILURE);
  }

  int	fdOut	= open(toFileCPtr,  O_WRONLY|O_TRUNC|O_CREAT,0660);

  if  (fdOut < 0)
  {
    fprintf(stderr,"Could not open %s.\n",toFileCPtr);
    close(fdIn);
    exit(EXIT_FAILURE);
  }

  char	buffer[BUFFER_SIZE];
  int	numBytes;

  while  ( (numBytes = read(fdIn,buffer,BUFFER_SIZE)) > 0 )
    write(fdOut,buffer,numBytes);

  close(fdOut);
  close(fdIn);
  return(EXIT_SUCCESS);
}
