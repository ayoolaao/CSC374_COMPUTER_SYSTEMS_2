#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

#define BUFFER_SIZE 256

/* Write a program that counts the number of occurrences
of a character given on the command line. */
int main (int argc, const char* argv[])
{
  const char* fileCPtr;
  if (argc < 3)
  {
    fprintf(stderr, "Usage: charCount <char> <file>\n");
    return(EXIT_FAILURE);
  }

  const char charToCount= *argv[1];
  fileCPtr = argv[2];

  /* YOUR CODE HERE */

  int	fdIn	= open(fileCPtr,O_RDONLY,0);

  if  (fdIn < 0)
  {
    fprintf(stderr,"Could not open %s\n",fileCPtr);
    exit(EXIT_FAILURE);
  }

  char	buffer[BUFFER_SIZE];
  int	count	= 0;
  int	numBytes;

  while  ( (numBytes = read(fdIn,buffer,BUFFER_SIZE)) > 0)
  {
    int	i;

    for  (i = 0;  i < numBytes;  i++)
      if  (buffer[i] == charToCount)
	count++;

  }

  close(fdIn);
  printf("%d\n",count);
  return(EXIT_SUCCESS);
}
