/*
 *	rescuingPlow.c
 *
 *	Compile with $ <i>gcc rescuingPlow.c -o rescuingPlow</i>
 */
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>


/*  PURPOSE:  To keep track of the number of victims that this process
 *	rescued.
 */
int	numVictimsRescued	= 0;



/*  PURPOSE:  To return the number of victims rescued to the OS.  'sigNum'
 *	tells the signal number.  No return value.
 */
void	reportHowManyVictimsWereRescued	(int	sigNum)
{

  //  I.  Applicability validity check:


  //  II.  Return value and quit:

  exit(numVictimsRescued);
}


/*  PURPOSE:  To install 'reportHowManyVictimsWereRescued()' as the SIGTERM
 *	signal handler.  No parameters.  No return value.
 */
void	installSigTermHandler	()
{
  struct sigaction act;

  memset(&act,'\0',sizeof(struct sigaction));
  sigemptyset(&act.sa_mask);
  act.sa_flags = 0;
  act.sa_handler = reportHowManyVictimsWereRescued;
               // Handle with simpleHandler()
  sigaction(SIGTERM,&act,NULL);

}


/*  PURPOSE:  To rescue victims at random intervals and inform parent process
 *	by sending it SIGUSR1 until receiving SIGTERM.  First parameter (after
 *	program name) tells parent's process id.  Second parameter tells this
 *	plow's index.
 */
int	main	(int argc, char* argv[])
{

  //  I.  Applicability validity check:

  pid_t	parentPID;
  int	plowId;

  if  (argc < 3)
  {
    fprintf(stderr,"USAGE: rescuingPlow <parentPID> <plowId>\n");
    return(EXIT_FAILURE);
  }

  parentPID	= strtol(argv[1],NULL,10);
  plowId	= strtol(argv[2],NULL,10);
  printf("Plow %d\n",plowId);


  //  II.  Rescuing victims until told to stop:

  //  II.A.  Install signal handler:
  installSigTermHandler();
  srand(plowId);  //  Uniquely initialize random number generator so they act independently of each other


  //  II.B.  Rescue victims:

  while  (1)
  {
    sleep((rand() % 6) + 1);
    numVictimsRescued++;
    printf("Plow %d rescued %d victim(s)!\n",plowId,numVictimsRescued);
    kill(parentPID,SIGUSR1);
  }


  //  III.  Finished:

  return(EXIT_SUCCESS);
}
