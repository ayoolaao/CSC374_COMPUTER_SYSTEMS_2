/*
 *	deptOfTrans.c
 *
 *	Compile with $ <em>gcc deptOfTrans.c -o deptOfTrans</em>
 */
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>


#define	TEXT_LEN		10
#define MAX_NUM_RESCUE_PLOWS	4
#define	NUM_VICTIMS_TO_RESCUE	40


/*  PURPOSE:  To keep trap of the number of victims that have been rescued.
 */
int	numRescuedVictims	= 0;



/*  PURPOSE:  To keep trap of the number of plow processes that currently exist.
 */
int	numPlowProcesses	= 0;



/*  PURPOSE:  To keep track of the process id's of the rescuing snow plows.
 */
pid_t	plowPid[MAX_NUM_RESCUE_PLOWS];


/*  PURPOSE:  To note that at least one child plow has finished.  Reports the
 *	process id and the number of victims rescued for each child plow.
 *	'sigNum' tells the signal number.  No return value
 */
void	noteHowManyVictimsPlowRescued	(int sigNum)
{

  //  I.  Applicability validity check:


  //  II.  wait() for child plows:
  int 	   plowId;
  int	   status;

  while  ( (plowId = waitpid(-1,&status,WNOHANG)) > 0 )
  {
    printf("Plow id %d rescued %d victims.\n",plowId,WEXITSTATUS(status));
    numPlowProcesses--;
  }

  //  III.  Finished:
}



/*  PURPOSE:  To handle being informed of a rescued victim.  'sigNum' tells
 *	signal number.  No return value.
 */
void	victimWasRescued	(int sigNum)
{

  //  I.  Applicability validiy check:


  //  II.  Handle being informed of a rescued victim:

  numRescuedVictims++;
  printf("We've rescued %d victim(s) total!\n",numRescuedVictims);


  //  III. Finished:

}


/*  PURPOSE:  To install 'victimWasRescued()' as the SIGUSR1 handler.  No
 *	parameters.  No return value.
 */
void	installSigUsr1Handler	()
{
  struct sigaction act;

  memset((void*)&act,(int)'\0',sizeof(struct sigaction));
  sigemptyset(&act.sa_mask);
  act.sa_flags		= 0;
  act.sa_handler	= victimWasRescued;
  sigaction(SIGUSR1,&act,NULL);

}


/*  PURPOSE:  To install 'noteHowManyVictimsPlowRescued()' as the SIGCHLD
 *	handler.  No parameters.  No return value.
 */
void	installSigChldHandler	()
{
  struct sigaction act;

  memset((void*)&act,(int)'\0',sizeof(struct sigaction));
  sigemptyset(&act.sa_mask);
  act.sa_flags		= 0;
  act.sa_handler	= noteHowManyVictimsPlowRescued;
  sigaction(SIGCHLD,&act,NULL);
}


/*  PURPOSE:  To make between 1 and 'MAX_NUM_RESCUE_PLOWS' processes to run
 *	'rescuingPlow' to rescue stuck victims, and then tell them to quit
 *	after all 'NUM_VICTIMS_TO_RESCUE' victims have been rescued.  Ignores
 *	parameters.  Returns 'EXIT_SUCCESS' to OS.
 */
int	main ()
{

  //  I.  Applicability validity check:


  //  II.  Rescue victims:
  //  II.A.  Get number of plows to make:
  char		text[TEXT_LEN];

  do
  {
    printf("Please enter the number of plows to deploy (1-%d): ",
	   MAX_NUM_RESCUE_PLOWS
	  );
    fgets(text,TEXT_LEN,stdin);
    numPlowProcesses = strtol(text,NULL,10);
  }
  while  ( (numPlowProcesses < 1)			||
	   (numPlowProcesses > MAX_NUM_RESCUE_PLOWS)
	 );

  //  II.B.  Install handlers:
  installSigUsr1Handler();

  //  II.C.  Tell 'numPlowProcesses' plows to start rescuing the victims:

  int i;
  int myPid	= getpid();

  for  (i = 0;  i < numPlowProcesses;  i++)
  {
    plowPid[i] = fork();

    if  (plowPid[i] < 0)
    {
      fprintf(stderr,"Dude, your system is WAY to busy to play rescuer!\n");
      return(EXIT_FAILURE);
    }
    else
    if  (plowPid[i] == 0)
    {
      char	pidText[TEXT_LEN];
      char	indexText[TEXT_LEN];

      snprintf(pidText,TEXT_LEN,"%d",myPid);
      snprintf(indexText,TEXT_LEN,"%d",i);
      execl("./rescuingPlow","rescuingPlow",pidText,indexText,NULL);
      fprintf(stderr,"Dude, somebody stole my plow!!\n");
      return(EXIT_FAILURE);
    }

  }

  //  II.D.  Wait until all victims have been rescued:
  while  (numRescuedVictims < NUM_VICTIMS_TO_RESCUE)
  {
    sleep(1);
    printf("Searching for victims . . .\n");
  }

  //  III.  Finished:
  installSigChldHandler();

  for  (i = 0;  i < numPlowProcesses;  i++)
    kill(plowPid[i],SIGTERM);


  do
  {
    sleep(1);
  }
  while  (numPlowProcesses > 0);

  printf("Ready for the NEXT snow storm!\n");
  return(EXIT_SUCCESS);
}
