/*-------------------------------------------------------------------------*
 *---									---*
 *---		dogEatThenDogPoop.cpp					---*
 *---									---*
 *---	    This file implements a multi-threaded application where	---*
 *---	there is a mutex lock on the gastro-intestinal tract of an	---*
 *---	instance of Canis lupus familiaris preventing it from eating	---*
 *---	pooping at the same time.					---*
 *---									---*
 *---	----	----	----	----	----	----	----	----	---*
 *---									---*
 *---	Version 1.0		2012 August 2		Joseph Phillips	---*
 *---									---*
 *---	Version 1.1		2014 August 5		Joseph Phillips	---*
 *---									---*
 *---	    Improved object-oriented design.				---*
 *---									---*
 *-------------------------------------------------------------------------*/

//  Compile with:
//  $ g++ dogEatThenDogPoop.cpp -o dogEatThenDogPoop -lpthread

//---			Inclusion of headers				---//

#include <cstdlib>
#include <cstdio>
#include <pthread.h>

using namespace std;



//---				Constants:				---//

const int	FULL_INTESTINE	= 4;

const int	NUM_DOG_CYCLES	= 32;

const int	MAX_LINE	= 256;



//---				Classes:				---//


//  PURPOSE:  To represent a Dog.
class	Dog
{
  //  V.  Member vars:
  //  PURPOSE:  To hold the Dog's name.
  const char*		namePtr_;

  //  PURPOSE:  To hold the fullness level of the Dog's gastro-intestinal tract.
  int 		   	gastroIntestinalFullness_;

  //  Perhaps member vars here:
  pthread_mutex_t	lock_;
  pthread_cond_t	notFamished_;
  pthread_cond_t	notStuffed_;

  //  II.  Disallowed auto-created methods:
  //  No default constructor:
  Dog 	 ();

  //  No copy constructor:
  Dog	(const Dog&);

  //  No copy assignment op:
  Dog&	operator=	(const Dog&);

protected :
  //  III.  Protected methods:

public : 
  //  IV. Constructor(s), factory(s), assignment op(s), destructor:
  //  PURPOSE:  To name '*this' Dog 'namePtr'.  No return value.
  Dog	(const char* newNamePtr) throw(const char*) :
	namePtr_(newNamePtr),
	gastroIntestinalFullness_(FULL_INTESTINE / 2)
  {
    //  I.  Applicability validity check:
    if  (newNamePtr == NULL)
      throw "NULL given to Dog constructor";

    //  II.  Initialize member vars:
    //  Do something here
    pthread_mutex_init(&lock_,NULL);
    pthread_cond_init(&notFamished_,NULL);
    pthread_cond_init(&notStuffed_,NULL);

    //  III.  Finished:
  }


  //  PURPOSE:  To release resources.  No parameters.  No return value.
  ~Dog	() throw()
  {
    //  I.  Applicability validity check:

    //  II.  Release resources:
    //  And here
    pthread_mutex_destroy(&lock_);
    pthread_cond_destroy(&notFamished_);
    pthread_cond_destroy(&notStuffed_);

    //  III.  Finished:
  }


  //  V.  Accessors:
  //  PURPOSE:  To return '*this' Dog's name.  No parameters.
  const char*	getNamePtr	() const throw()	{ return(namePtr_); }

  //  You may want to add some accessors:
  pthread_mutex_t*
		getLockPtr	() throw()	{ return(&lock_); }

  //  PURPOSE:  To return 'true' if the gastrointestinal tract of '*this' Dog
  //  	is full or 'false' otherwise.  No parameters.
  bool		isStuffed () const throw()
	{ return(gastroIntestinalFullness_ == FULL_INTESTINE); }

  //  PURPOSE:  To return 'true' if the gastrointestinal tract of '*this' Dog
  //  	is empty or 'false' otherwise.  No parameters.
  bool		isFamished () const throw()
	{ return(gastroIntestinalFullness_ == 0); }

  //  VI.  Mutators:


  //  VII.  Methods that do main work of class:
  //  PURPOSE:  To walk '*this' Dog and partially empty out its G-I tract.
  //  	No parameters.  No return value.
  void		walk	() throw()
  {
    const char*	poopArray[]	= {"Nature calls",
    	  			   "Don't step in that!",
				   "Eeww!",
				   "All things must pass.",
				   "What goes in must come out."
				  };

    // Pre-critical section code here
    pthread_mutex_lock(getLockPtr());

    while  (isFamished() )
    {
      printf("Walker: %s is famished, not need to walk him.\n",getNamePtr());
      pthread_cond_wait(&notFamished_,getLockPtr());
    }

    //  Critical section (leave this alone):
    gastroIntestinalFullness_--;
    printf("Walker: \"%s\" (%d)\n",
    	   poopArray[rand() % (sizeof(poopArray)/sizeof(const char*))],
	   gastroIntestinalFullness_
	  );

    // Post-critical section code here
    pthread_cond_signal(&notStuffed_);
    pthread_mutex_unlock(getLockPtr());
  }


  //  PURPOSE:  To let the Dog eat and partially fill up its G-I tract.
  //  	No parameters.  No return value.
  void		eat	() throw()
  {
    const char*	eatArray[]	= {"Munch munch",
    	  			   "Crunch crunch",
				   "Chew chew chew",
				   "(Slobber)"
				  };

    // Pre-critical section code here
    pthread_mutex_lock(getLockPtr());

    while  (isStuffed() )
    {
      printf("%s: I'm stuffed!  I'm not hungry!\n",getNamePtr());
      pthread_cond_wait(&notStuffed_,&lock_);
    }

    //  Critical section (leave this alone):
    gastroIntestinalFullness_++;
    printf("%s: \"%s\" (%d)\n",
	   getNamePtr(),
	   eatArray[rand() % (sizeof(eatArray) / sizeof(const char*))],
	   gastroIntestinalFullness_
	  );

    // Post-critical section code here
    pthread_cond_signal(&notFamished_);
    pthread_mutex_unlock(getLockPtr());
  }

};


//  PURPOSE:  To represent a DogWalker.
class	DogWalker
{
  //  I.  Member vars:
  //  PURPOSE:  To refer to the Dog being walked:
  Dog&		dog_;

  //  II.  Disallowed auto-created methods:
  //  No default constructor:
  DogWalker 	 ();

  //  No copy constructor:
  DogWalker	(const DogWalker&);

  //  No copy assignment op:
  DogWalker&	operator=	(const DogWalker&);

protected :
  //  III.  Protected methods:

public :
  //  IV. Constructor(s), factory(s), assignment op(s), destructor:
  //  PURPOSE:  To name '*this' DogWalker 'namePtr'.  No return value.
  DogWalker	(Dog&  		newDog
		)
		throw(const char*) :
	dog_(newDog)
  {
    //  I.  Applicability validity check:

    //  II.  Initialize member vars:

    //  III.  Finished:
  }

  //  PURPOSE:  To release resources.  No parameters.  No return value.
  ~DogWalker	()	{ }

  //  V.  Accessors:
  //  PURPOSE:  To return a reference to the Dog walked by '*this'.  No
  //    parameters.
  Dog&	getDog () const throw()	{ return(dog_); }

  //  VI.  Mutators:

  //  VII.  Methods that do main work of class:

};



//---				Functions:				---//

//  PURPOSE:  To return a random dog name.  No parameters.
const char*	getRandomDogName	()
{
  const char*	dogNameArray[]		= {"Astro",
      					   "Clifford",
					   "Dino",
					   "Muttley",
					   "Gromit",
					   "Mr. Peabody",
					   "Odie",
					   "Pluto",
					   "Santa's Little Helper",
					   "Scooby Doo",
					   "Snoopy",
					   "Fido"
					  };

  const int	NUM_DOG_NAMES		= sizeof(dogNameArray) /
      					  sizeof(const char*);

  return(dogNameArray[rand() % NUM_DOG_NAMES]);
}


//  PURPOSE:  To let the DogWalker pointed to by '(DogWalker*)ptr' walk its
//	dog.  Returns 'NULL' which should be ignored.
void*	doWalker	(void*	ptr)
{
  DogWalker*	walkerPtr	= (DogWalker*)ptr;

  for  (int i = 0;  i < NUM_DOG_CYCLES;  i++)
    walkerPtr->getDog().walk();

  return(NULL);
}



//  PURPOSE:  To let the Dog pointed to by '(Dog*)ptr' walk its dog.
//	Returns 'NULL' which should be ignored.
void*	doDog	(void*	ptr)
{
  Dog*	dogPtr	= (Dog*)ptr;

  for  (int i = 0;  i < NUM_DOG_CYCLES;  i++)
    dogPtr->eat();

  return(NULL);
}



//  PURPOSE:  To let the dog eat and let the dog walker walk the dog.
//	'argc' tells the number of arguments.  'argv[1]', if present, will be
//	used to as the random number seed.  Returns 'EXIT_SUCCESS' to OS.
int	main	(int argc, const char* argv[])
{

  //  I.  Applicability validity check:

  //  II.  Let the dog eat and let the dog walker walk the dog:
  //  II.A.  Set the random number seed:
  int		seed;
  const	char*	cPtr;
  char		text[MAX_LINE];

  if  (argc > 1)
    cPtr = argv[1];
  else
  {
    printf("Random number seed? ");
    fgets(text,MAX_LINE,stdin);
    cPtr = text;
  }

  srand(strtol(cPtr,NULL,10));

  //  II.B.  Make Dog and DogWalker:
  Dog		dog(getRandomDogName());
  DogWalker	walker(dog);

  //  II.C.  Do threads for Dog to eat and DogWalker to walk the Dog:
  //  Maybe some variables here:
  pthread_t	dogThread;
  pthread_t	walkerThread;

  if  (rand() % 2)
  {
    //  Thread for doDog() given the address of dog.
    //  then thread for doWalker() given the address of walker.
    pthread_create(&dogThread,NULL,doDog,&dog);
    pthread_create(&walkerThread,NULL,doWalker,&walker);
  }
  else
  {
    //  Thread for doWalker() given the address of walker.
    //  then thread for doDog() given the address of dog.
    pthread_create(&walkerThread,NULL,doWalker,&walker);
    pthread_create(&dogThread,NULL,doDog,&dog);
  }

  //  Wait for both threads
  pthread_join(dogThread,NULL);
  pthread_join(walkerThread,NULL);

  //  III.  Finished:
  return(EXIT_SUCCESS);
}
