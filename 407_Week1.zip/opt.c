for  (i = 0;  i < n;  i++)
{
    int	in = i*n;
    for  (j = 0;  j < n;  j++)
    {
	int  ij	= i*j;
	int  in_ij = in + i*j;
        for  (k = 0;  k < j;  k++)
            a[in_ij - k] = b[k*7];
    }
}


int	nn	= n*n;
int	middle	= i *nn + j*n + k

above = array[middle + nn];
below = array[middle - nn];
left  = array[middle - n];
right = array[middle + n];
front = array[middle - 1];
back  = array[middle + 1];

aver = (above+below+
        right+front+
        back+left)/6;


int in = 0;
for  (i = 0;  i < n;  i++)
{
    int ij = 0;
    int in_ij = in + ij;
    for  (j = 0;  j < n;  j++)
    {
        for  (k = 0;  k < j;  k++)
            a[in_ij - k] = b[(k << 3) - k ];
	ij += i;
    }
    in += n;
}






