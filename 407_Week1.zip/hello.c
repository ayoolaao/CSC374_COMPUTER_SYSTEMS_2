#include <stdlib.h>
#include <stdio.h>

#define	MESSAGE	"hello class\n"

int	main	()
{
  printf(MESSAGE);
  return(EXIT_SUCCESS);
}
