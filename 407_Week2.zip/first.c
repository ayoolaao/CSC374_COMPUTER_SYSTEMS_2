#include	<stdlib.h>
#include	<stdio.h>

extern	void	enterBeginEnd	();
extern	void	printFromBeginToEnd	();

char	begin,end;

int	main	()
{
  enterBeginEnd();
  printFromBeginToEnd();
  return(EXIT_SUCCESS);
}
