#include	<stdlib.h>
#include	<stdio.h>

extern	char	begin;
extern	char	end;

#define	SIZE	4

void	enterBeginEnd	()
{
  char	array[SIZE];

  printf("First char: ");
  fgets(array,SIZE,stdin);
  begin = array[0];
//fgets(&begin,1,stdin);

  do
  {
    printf("Second char: ");
    fgets(array,SIZE,stdin);
    end = array[0];
//  fgets(&end,1,stdin);
  }
  while  (end < begin);
}
