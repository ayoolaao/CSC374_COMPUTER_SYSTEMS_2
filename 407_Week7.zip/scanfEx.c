#include	<stdlib.h>
#include	<stdio.h>
#include	<string.h>

#define		MAX_LINE	256

int	main	()
{
  printf("Please enter an integer an a float: ");
  char	line[MAX_LINE];
  int	i;
  float	f;

  int	numRead	= fscanf(stdin,"%d %f",&i,&f);

  printf("Read %d thing(s): i = %d, f = %f\n",numRead,i,f);

  do
  {
    printf("Please enter an integer an a float: ");
    fgets(line,MAX_LINE,stdin);
    numRead = sscanf(line,"%d %f",&i,&f);
  }
  while  (numRead < 2);

  printf("Read %d thing(s): i = %d, f = %f\n",numRead,i,f);
  return(EXIT_SUCCESS);
}
