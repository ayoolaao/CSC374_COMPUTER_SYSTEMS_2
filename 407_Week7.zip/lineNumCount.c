#include	<stdlib.h>
#include	<stdio.h>
#include	<string.h>

#define		MAX_LINE	256

int	main	(int	argc,
		 char*	argv[]
		)
{
  if  (argc < 2)
  {
    fprintf(stderr,"Usage:\tlineNumCount <filename>\n");
    exit(EXIT_FAILURE);
  }

  const char*	filename= argv[1];
  FILE*		file	= fopen(filename,"r");

  if  (file == NULL)
  {
    fprintf(stderr,"You moron!  Could not open %s.\n",filename);
    exit(EXIT_FAILURE);
  }

  char	buffer[MAX_LINE];
  int	counter		= 0;

  while  (fgets(buffer,MAX_LINE,file) != NULL)
    if  ( strchr(buffer,'\n') != NULL)
      counter++;

  fclose(file);
  printf("%d\n",counter);
  return(EXIT_SUCCESS);
}
