#include	<stdlib.h>
#include	<stdio.h>
#include	<string.h>

#define		MAX_LINE	256

int	main	(int	argc,
		 char*	argv[]
		)
{
  if  (argc < 3)
  {
    fprintf(stderr,"Usage:\tlineCounter <string> <filename>\n");
    exit(EXIT_FAILURE);
  }

  const char*	target	= argv[1];
  const char*	filename= argv[2];
  FILE*		file	= fopen(filename,"r");

  if  (file == NULL)
  {
    fprintf(stderr,"You moron!  Could not open %s.\n",filename);
    exit(EXIT_FAILURE);
  }

  char	buffer[MAX_LINE];
  int	counter		= 0;
  int	targetLen	= strlen(target);

  while  (fgets(buffer,MAX_LINE,file) != NULL)
    if  ( strncmp(target,buffer,targetLen) == 0 )
      counter++;

  fclose(file);
  printf("%d\n",counter);
  return(EXIT_SUCCESS);
}
