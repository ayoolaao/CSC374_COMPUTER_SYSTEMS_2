#include	<stdlib.h>
#include	<stdio.h>
#include	<string.h>

#define		MAX_LINE	256
#define		COMMENT_CHAR	'#'

int		main	(int	argc,
			 char*	argv[]
			)
{
  if  (argc < 2)
  {
    fprintf(stderr,"Missing filename.\n");
    exit(EXIT_FAILURE);
  }

  const char*	filename	= argv[1];
  FILE*		file		= fopen(filename,"r");

  if  (file == NULL)
  {
    fprintf(stderr,"Could not open %s.\n",filename);
    exit(EXIT_FAILURE);
  }

  char	buffer[MAX_LINE];
  int	counter		= 0;
  int	lineNumber	= 0;

  while  (fgets(buffer,MAX_LINE,file) != NULL)
  {
    lineNumber++;

    char*	cPtr;
    int		i;
    int		j;

    for  (cPtr = buffer;  *cPtr != '\0';  cPtr++)
      if  ( !isspace(*cPtr) )
	break;

    switch  (*cPtr)
    {
    case '\0' :
      continue;

    case COMMENT_CHAR :
      continue;

    case '0' :
    case '1' :
    case '2' :
    case '3' :
    case '4' :
    case '5' :
    case '6' :
    case '7' :
    case '8' :
    case '9' :
      if  (sscanf(cPtr,"%d %d",&i,&j) == 2)
        counter++;
      else
        fprintf(stderr,"Insufficient ints on line %d.\n",lineNumber);
      break;

    default :
      fprintf(stderr,"Insufficient ints on line %d.\n",lineNumber);
    }

  }

  fclose(file);
  printf("%d\n",counter);
  return(EXIT_SUCCESS);
}
