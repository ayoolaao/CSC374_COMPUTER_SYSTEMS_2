#include	<stdlib.h>
#include	<stdio.h>
#include	<string.h>
#include	<sys/types.h>
#include	<dirent.h>
#include <sys/stat.h>
#include <unistd.h>


#define		MAX_LINE	256

int		main	(int	argc,
			 char*	argv[]
			)
{
  const char*	dirname;

  if  (argc == 1)
    dirname	= ".";
  else
    dirname	= argv[1];

  DIR*	dir	= opendir(dirname);

  if  (dir == NULL)
  {
    fprintf(stderr,"Cannot open directory %s.\n",dirname);
    exit(EXIT_FAILURE);
  }

  struct dirent*	dirEntryPtr;
  struct stat		statBuf;

  while  ( (dirEntryPtr = readdir(dir)) != NULL )
  {
    char	entryName[MAX_LINE];

    strncpy(entryName,dirname,MAX_LINE);

    int		length	= strlen(entryName);

    strncat(entryName,"/",MAX_LINE - length);
    length++;
    strncat(entryName,dirEntryPtr->d_name,MAX_LINE-length);

    stat(entryName,&statBuf);

    if  (S_ISREG(statBuf.st_mode) )
      printf("%s (%d)\n",dirEntryPtr->d_name,statBuf.st_size);
    else
    if  (S_ISDIR(statBuf.st_mode) )
      printf("%s (dir)\n",dirEntryPtr->d_name);
    else
      printf("%s (other)\n",dirEntryPtr->d_name);
  } 

  closedir(dir);
  return(EXIT_SUCCESS);
}
