#include	<stdlib.h>
#include	<stdio.h>
#include	<string.h>
#include	<sys/types.h>
#include	<dirent.h>

int		main	(int	argc,
			 char*	argv[]
			)
{
  const char*	dirname;

  if  (argc == 1)
    dirname	= ".";
  else
    dirname	= argv[1];

  DIR*	dir	= opendir(dirname);

  if  (dir == NULL)
  {
    fprintf(stderr,"Cannot open directory %s.\n",dirname);
    exit(EXIT_FAILURE);
  }

  struct dirent*	dirEntryPtr;

  while  ( (dirEntryPtr = readdir(dir)) != NULL )
  {
//  printf("%s\n",dirEntryPtr->d_name);
    printf("%s\n",(*dirEntryPtr).d_name);
  } 

  closedir(dir);
  return(EXIT_SUCCESS);
}
