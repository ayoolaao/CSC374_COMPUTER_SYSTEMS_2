#include	<stdlib.h>
#include	<stdio.h>
#include	<string.h>


char* naughtyCopy (const char* fromP)
{
  char* toP = (char*)malloc(strlen(fromP)+1);
  char* start = toP;

  for  ( ;  *fromP != '\0'; fromP++, toP++)
    *toP = *fromP;

  *toP = '\0';
  return(start); 
}


int	main	()
{
  char*	copyPtr = naughtyCopy("See you tomorrow!\n");

  printf("%s",copyPtr);
  free(copyPtr);
  return(EXIT_SUCCESS);
}
