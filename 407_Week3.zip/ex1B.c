#include	<stdlib.h>
#include	<stdio.h>

int	main	()
{
  int	i;
  int	sum	= 0;
  pid_t	pid	= fork();

  if  (pid != 0)
  {
    for  (i = 1;  i <= 50;  i++)
      sum += i;
  }
  else
  {
    for  (i = 51;  i <= 100;  i++)
      sum += i;
  }

  printf("Process %d's sum is: %d\n",
	 getpid(),sum
	);
  return(EXIT_SUCCESS);
}
