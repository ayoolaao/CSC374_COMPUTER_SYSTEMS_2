#include	<stdlib.h>
#include	<stdio.h>
#include	<string.h>
#include	<unistd.h>

#define		TEXT_LEN	256

int	main	()
{
  char  line[TEXT_LEN];

  printf("What program do you want to run? ");
  fgets(line,TEXT_LEN,stdin);
  char* cPtr = strchr(line,'\n');
  if  (cPtr != NULL)
    *cPtr = '\0';

  pid_t	pid	= fork();

  if  (pid == 0)
    execl(line,line,NULL);
  else
    printf("Mama is finished!\n");

  return(EXIT_SUCCESS);
}
