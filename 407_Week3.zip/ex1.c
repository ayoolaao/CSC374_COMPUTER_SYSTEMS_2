#include	<stdlib.h>
#include	<stdio.h>

int	bssVar		= 0;
int	dataVar		= 7;

int	main	()
{
  int	stackVar	= 5;
  int*	heapPtr		= (int*)malloc(sizeof(int));

  *heapPtr		= 63;

  pid_t	pid		= fork();

  if  (pid != 0)
  {
    bssVar++;
    dataVar++;
    stackVar++;
    (*heapPtr)++;
  }
  else
  {
    bssVar--;
    dataVar--;
    stackVar--;
    (*heapPtr)--;
  }

  printf("Hello from process %d: bss = %d, data = %d, stack = %d, heap = %d\n",
	 getpid(),bssVar,dataVar,stackVar,*heapPtr
	);
  return(EXIT_SUCCESS);
}
