#include	<stdlib.h>
#include	<stdio.h>
#include	<unistd.h>

int	main	()
{
  execl("printCmdLineParams",	// For the OS, so it knows what to run
	"printCmdLineParams",	// for the process itself, so it knows
				//  which program it is running
	"A",			// Optional
	"B",			// Optional
	"C",			// Optional
	"Mary had a little lamb",// Optional
	"whose fleece was white as snow",// Optional
	"Something else",	// Optional
	NULL			// NEED because it marks the last
       );
}

