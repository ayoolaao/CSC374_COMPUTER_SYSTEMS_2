#include	<stdlib.h>
#include	<stdio.h>
#include	<signal.h>
#include	<string.h>

int	main	()
{
  //  Create instance
  struct sigaction act;

  //  Set all member vars to 0 in instance
  memset(&act,'\0',sizeof(struct sigaction));
  sigemptyset(&act.sa_mask);
  act.sa_flags = 0;

  //  Set appropriate member vars
  act.sa_handler = SIG_IGN;// Ignore SIGINT
  sigaction(SIGINT,&act,NULL);
  sigaction(SIGALRM,&act,NULL);
  sigaction(SIGKILL,&act,NULL);

  while  (1)
  {
    printf("You can't stop me!  Ngyeah-ngyeah!\n");
    sleep(2);
  }

  return(EXIT_SUCCESS);
}
