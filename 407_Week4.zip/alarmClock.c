#include	<stdlib.h>
#include	<stdio.h>
#include	<string.h>
#include	<signal.h>
//#include	<alarm.h>

#define		TEXT_LEN	64

int	shouldStillRun		= 1;

void	sigAlrmHandler	(int	sig
			)
{
  shouldStillRun	= 0;
}


void	sigIntHandler	(int	sig
			)
{
  int	remainingTime	= alarm(0);
  char	text[TEXT_LEN];

  printf("%d seconds remain, press enter to continue:",remainingTime);
  fgets(text,TEXT_LEN,stdin);
  alarm(remainingTime);
}

int	main	()
{
  char	text[TEXT_LEN];
  int	time;

  printf("Time before alarm goes off? ");
  fgets(text,TEXT_LEN,stdin);
  time = strtol(text,NULL,10);

  // Set up struct to specify the new action.
  struct sigaction act;

  memset(&act,'\0',sizeof(struct sigaction));
  sigemptyset(&act.sa_mask);
  act.sa_flags = 0;
  act.sa_handler = sigAlrmHandler;
  sigaction(SIGALRM,&act,NULL);

  act.sa_handler = sigIntHandler;
  sigaction(SIGINT,&act,NULL);

  alarm(time);

  while  (shouldStillRun)
    printf("Tick-tock!\n");

  printf("Ding Ding Ding!\n");
  return(EXIT_SUCCESS);
}
