#include	<stdlib.h>
#include	<stdio.h>
#include	<string.h>
#include	<signal.h>

void	sigIntHandler	(int		sig,
			 siginfo_t*	infoPtr,
			 void*		dataPtr
			)
{
  if  (infoPtr->si_pid == getppid())
    printf("Hee-hee!  That tickles!\n");
  else
    printf("Leave me alone!  Keep your hands to yourself MISTER!\n");
}


int	main	()
{
  pid_t	childId	= fork();

  if  (childId == 0)
  {
    struct sigaction sa;

    memset(&sa,'\0',sizeof(struct sigaction));
    sigemptyset(&sa.sa_mask );

    sa.sa_flags= SA_SIGINFO //Install sa_sigaction
                          // (as opposed to
                          //  sa_handler)
               | SA_RESTART;//If interrupted in
                          // sys call then
                          // restart sys call
                          // after signal handler

    sa.sa_sigaction = sigIntHandler;
    sigaction(SIGINT, &sa, NULL);

    while (1)
      sleep(1);

    exit(EXIT_SUCCESS);
  }

  printf("Child id = %d\n",childId);

  char line[10];
  int  i;

  for  (i = 0;  i < 4;  i++)
  {
    printf("Please press enter to tickle child:\n");
    fgets(line,10,stdin);
    kill(childId,SIGINT);
  }

  return(EXIT_SUCCESS);
}
