#include	<stdlib.h>
#include	<stdio.h>

int	main	()
{
  int i;

  for  (i = 0;  i < 10;  i++)
  {
    printf("Hello class %d\n",i);
    sleep(1);
  }
  return(EXIT_SUCCESS);
}
