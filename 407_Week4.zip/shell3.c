#include	<stdlib.h>
#include	<stdio.h>
#include	<string.h>
#include	<unistd.h>
#include	<wait.h>
#include	<signal.h>

#define		TEXT_LEN	256

void	sigChldHander	(int	sig
			)
{
  pid_t	pid;
  int	status;

  while  ( (pid = waitpid(-1,&status,WNOHANG)) > 0)
    if  (WIFEXITED(status) != 0)
      printf("Child %d did NOT crash and it returned %d\n",
	     pid,WEXITSTATUS(status)
	    );
    else
      printf("Child %d crashed! :(\n",pid);
}


void	installSigChldHandler	()
{
  // Set up struct to specify the new action.
  struct sigaction act;

  memset(&act,'\0',sizeof(struct sigaction));
  sigemptyset(&act.sa_mask);
  act.sa_flags = SA_RESTART | SA_NOCLDSTOP;

  act.sa_handler = sigChldHander;
  sigaction(SIGCHLD,&act,NULL);

  printf("SA_RESTART = %X\nSA_NOCLDSTOP = %X\n",
	 SA_RESTART,SA_NOCLDSTOP
	);
}


int	main	()
{
  char  line[TEXT_LEN];

  installSigChldHandler();

  do
  {
    printf("What program do you want to run? ");
    fgets(line,TEXT_LEN,stdin);
    char* cPtr = strchr(line,'\n');
    if  (cPtr != NULL)
      *cPtr = '\0';

    pid_t	pid	= fork();

    if  (pid == 0)
    {
      execl(line,line,NULL);
      printf("Could not find %s\n",line);
      exit(EXIT_FAILURE);
    }

  }
  while  (1);

  return(EXIT_SUCCESS);
}
