#include	<stdlib.h>
#include	<stdio.h>
#include	<signal.h>
#include	<string.h>

void	handleSigInt	(int	sig
			)
{
  switch  (rand() % 4)
  {
  case 0 : printf("Ouch!\n");		break;
  case 1 : printf("Stop that!\n");	break;
  case 2 : printf("That hurts!\n");	break;
  case 3 : printf("What the heck!\n");		break;
  }
}

int	main	()
{
  //  Create instance
  struct sigaction act;

  //  Set all member vars to 0 in instance
  memset(&act,'\0',sizeof(struct sigaction));
  sigemptyset(&act.sa_mask);
  act.sa_flags = 0;

  //  Set appropriate member vars
  act.sa_handler = handleSigInt;// Ignore SIGINT
  sigaction(SIGINT,&act,NULL);

  while  (1)
  {
    printf("You can't stop me!  Ngyeah-ngyeah!\n");
    sleep(2);
  }

  return(EXIT_SUCCESS);
}
