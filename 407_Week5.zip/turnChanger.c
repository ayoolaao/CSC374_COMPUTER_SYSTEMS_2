#include	<stdlib.h>
#include	<stdio.h>
#include	<pthread.h>

int	turn	= 0;

void*	turnTo1	(void* vPtr)
{
  int	i;

  for  (i = 0;  i < 4;  i++)
  {
    while  (turn == 1) { }
    turn = 1;
    printf("Turn == 1!\n");
  }

  return(NULL);
}

void*	turnTo0	(void* vPtr)
{
  int	i;

  for  (i = 0;  i < 4;  i++)
  {
    while  (turn == 0) { }
    turn = 0;
    printf("Turn == 0!\n");
  }
  return(NULL);
}

int	main	()
{
  pthread_t	thread0;
  pthread_t	thread1;

  pthread_create(&thread0,NULL,turnTo1,NULL);
  pthread_create(&thread1,NULL,turnTo0,NULL);

  pthread_join(thread0,NULL);
  pthread_join(thread1,NULL);
  return(EXIT_SUCCESS);
}
