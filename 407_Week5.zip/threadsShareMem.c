#include	<stdlib.h>
#include	<stdio.h>
#include	<pthread.h>

int		data	= 4;
int		bss	= 0;
int*		heapPtr;

void*	insulter(void*	vPtr
		)
{
  int	integer	= *(int*)vPtr;

  data++;
  bss++;
  (*heapPtr)++;
  switch (integer)
  {
  case 0 : printf("You smell!\n"); break;
  case 1 : printf("Oh no!\n"); break;
  case 2 : printf("You look hungry!\n"); break;
  case 3 : printf("Somebody got up on the wrong side of the bed!\n"); break;
  }
  return(NULL);
}


int	main	()
{
  pthread_t	tid[4];
  int		i;

  heapPtr	= (int*)malloc(sizeof(int));
  *heapPtr	= 20;

  for  (i = 0;  i < 4;  i++)
    pthread_create(&tid[i],NULL,insulter,&i);

  for  (i = 0;  i < 4;  i++)
    pthread_join(tid[i],NULL);

  printf("data = %d, bss = %d, *heapPtr = %d\n",data,bss,(*heapPtr));
  free(heapPtr);
  return(EXIT_SUCCESS);
}
